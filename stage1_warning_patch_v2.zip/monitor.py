from __future__ import annotations

"""
Live monitoring module.

Runs a background async loop that polls Binance every POLL_SEC seconds.
For each "hot" coin from morning analysis:
  - If no position: checks entry conditions on last closed bar
  - If in position: checks exit conditions + validates forward predictions
  
Sends Telegram messages via callback for all meaningful events.
"""

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Dict, List, Optional

import aiohttp
import numpy as np

import config
from indicators import compute_features
from strategy import (
    CoinReport, fetch_klines,
    check_entry_conditions, check_exit_conditions,
    check_retest_conditions, check_breakout_conditions,
    check_impulse_conditions, check_alignment_conditions,
    get_entry_mode,
)
import botlog

log = logging.getLogger(__name__)


# ── Portfolio risk helpers ─────────────────────────────────────────────────────

def _get_coin_group(sym: str) -> Optional[str]:
    """Возвращает название группы монеты или None."""
    groups = getattr(config, "COIN_GROUPS", {})
    for grp, members in groups.items():
        if sym in members:
            return grp
    return None



async def _check_mtf(
    session: aiohttp.ClientSession,
    sym: str,
) -> tuple[bool, str]:
    """
    MTF (Multi-TimeFrame) фильтр: перед входом по 1h проверяет 15м индикаторы.
    Защищает от запоздавших входов когда 1h ещё «красивый», но 15м уже в коррекции.

    Возвращает (True, "OK") если 15м подтверждает вход,
    или (False, причина) если 15м показывает коррекцию.

    Примеры ложных 1h входов без MTF:
      ETH 13.03 — пик 14:15, 1h вход 16:00, 15м MACD=-6.78, RSI=41.
    """
    if not getattr(config, "MTF_ENABLED", True):
        return True, "MTF disabled"

    # Грузим 15м данные (достаточно 100 баров для EMA50/MACD)
    data_15m = await fetch_klines(session, sym, "15m", limit=100)
    if data_15m is None or len(data_15m) < 40:
        # Нет данных → не блокируем (fail-open: лучше ложный вход, чем пропуск)
        return True, "no 15m data"

    c = data_15m["c"].astype(float)
    feat_15m = compute_features(
        data_15m["o"], data_15m["h"], data_15m["l"], c, data_15m["v"]
    )
    i = len(c) - 2  # последний закрытый 15м бар

    macd_hist = float(feat_15m["macd_hist"][i]) if np.isfinite(feat_15m["macd_hist"][i]) else 0.0
    rsi_val   = float(feat_15m["rsi"][i])       if np.isfinite(feat_15m["rsi"][i])       else 50.0

    # Проверка 1: MACD hist > 0 на 15м
    if getattr(config, "MTF_MACD_POSITIVE", True) and macd_hist <= 0:
        return False, f"15м MACD hist={macd_hist:.4g} ≤ 0 (коррекция)"

    # Проверка 2: RSI >= MTF_RSI_MIN на 15м
    mtf_rsi_min = getattr(config, "MTF_RSI_MIN", 45.0)
    if rsi_val < mtf_rsi_min:
        return False, f"15м RSI={rsi_val:.1f} < {mtf_rsi_min} (коррекция)"

    return True, f"15м OK: MACD={macd_hist:.4g} RSI={rsi_val:.1f}"


# ── Position persistence ───────────────────────────────────────────────────────
import os as _os_pers
import json as _json_pers

def _pos_to_dict(pos: "OpenPosition") -> dict:
    return {
        "symbol": pos.symbol, "tf": pos.tf,
        "entry_price": pos.entry_price, "entry_bar": pos.entry_bar,
        "entry_ts": pos.entry_ts, "entry_ema20": pos.entry_ema20,
        "entry_slope": pos.entry_slope, "entry_adx": pos.entry_adx,
        "entry_rsi": pos.entry_rsi, "entry_vol_x": pos.entry_vol_x,
        "predictions": {str(k): v for k, v in pos.predictions.items()},
        "bars_elapsed": pos.bars_elapsed, "ml_record_id": pos.ml_record_id,
        "signal_mode": pos.signal_mode, "trail_k": pos.trail_k,
        "max_hold_bars": pos.max_hold_bars, "trail_stop": pos.trail_stop,
        "macd_warn_streak": pos.macd_warn_streak, "macd_warned": pos.macd_warned,
        "last_macd_bar_i": pos.last_macd_bar_i,
    }

def _pos_from_dict(d: dict) -> "OpenPosition":
    return OpenPosition(
        symbol=d["symbol"], tf=d["tf"], entry_price=d["entry_price"],
        entry_bar=d["entry_bar"], entry_ts=d["entry_ts"],
        entry_ema20=d.get("entry_ema20", 0.0), entry_slope=d.get("entry_slope", 0.0),
        entry_adx=d.get("entry_adx", 0.0), entry_rsi=d.get("entry_rsi", 50.0),
        entry_vol_x=d.get("entry_vol_x", 1.0),
        predictions={int(k): v for k, v in d.get("predictions", {}).items()},
        bars_elapsed=d.get("bars_elapsed", 0), ml_record_id=d.get("ml_record_id", ""),
        signal_mode=d.get("signal_mode", "trend"), trail_k=d.get("trail_k", 2.0),
        max_hold_bars=d.get("max_hold_bars", 16), trail_stop=d.get("trail_stop", 0.0),
        macd_warn_streak=d.get("macd_warn_streak", 0),
        macd_warned=d.get("macd_warned", False),
        last_macd_bar_i=d.get("last_macd_bar_i", -1),
    )

def save_positions(positions: dict) -> None:
    """Атомарно сохраняет позиции на диск."""
    path = getattr(config, "POSITIONS_FILE", "positions.json")
    try:
        data = {sym: _pos_to_dict(pos) for sym, pos in positions.items()}
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            _json_pers.dump(data, f, ensure_ascii=False, indent=2)
        _os_pers.replace(tmp, path)
    except Exception as e:
        log.warning("save_positions failed: %s", e)

def load_positions() -> dict:
    """Восстанавливает позиции при старте бота."""
    path = getattr(config, "POSITIONS_FILE", "positions.json")
    if not _os_pers.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = _json_pers.load(f)
        positions = {sym: _pos_from_dict(d) for sym, d in data.items()}
        log.info("Restored %d position(s) from %s: %s",
                 len(positions), path, list(positions.keys()))
        return positions
    except Exception as e:
        log.warning("load_positions failed: %s — starting empty", e)
        return {}


def _check_portfolio_limits(sym: str, state: "MonitorState") -> tuple[bool, str]:
    """
    Проверяет портфельные лимиты перед входом в позицию.

    Возвращает (ok: bool, reason: str).

    Лимиты:
      1. MAX_OPEN_POSITIONS — не более N одновременных позиций
      2. MAX_POSITIONS_PER_GROUP — не более M позиций в одной группе монет
         (защита от ситуации 11.03.2026 когда 12 L1/AI вошли одновременно)
    """
    max_pos  = getattr(config, "MAX_OPEN_POSITIONS",    6)
    max_grp  = getattr(config, "MAX_POSITIONS_PER_GROUP", 2)

    # Лимит 1: общее число позиций
    n_open = len(state.positions)
    if n_open >= max_pos:
        return False, f"портфель полон: {n_open}/{max_pos} позиций"

    # Лимит 2: группа монеты
    my_group = _get_coin_group(sym)
    if my_group:
        group_count = sum(
            1 for s in state.positions
            if _get_coin_group(s) == my_group
        )
        if group_count >= max_grp:
            return False, (
                f"группа '{my_group}' уже {group_count}/{max_grp} позиций "
                f"({', '.join(s for s in state.positions if _get_coin_group(s) == my_group)})"
            )

    return True, ""


SendFn = Callable[[str], Awaitable[None]]


# ── Position tracking ──────────────────────────────────────────────────────────

@dataclass
class OpenPosition:
    symbol:      str
    tf:          str
    entry_price: float
    entry_bar:   int          # index within the candle array at entry time
    entry_ts:    int          # unix ms timestamp of entry bar

    # Snapshot of indicators at entry (for context in messages)
    entry_ema20: float
    entry_slope: float
    entry_adx:   float
    entry_rsi:   float
    entry_vol_x: float

    # Forward prediction tracking: {horizon_bars: True/False/None}
    predictions: Dict[int, Optional[bool]] = field(default_factory=dict)
    bars_elapsed: int = 0

    # ML: id записи в ml_dataset.jsonl для обновления меток
    ml_record_id:  str   = ""

    # П1: режим сигнала определяет trail_k и max_hold_bars
    signal_mode:   str   = "trend"    # "trend"/"strong_trend"/"retest"/"breakout"
    trail_k:       float = 2.0        # множитель ATR (берётся из config по режиму)
    max_hold_bars: int   = 16         # лимит баров в позиции (по режиму)

    # ATR trailing stop — обновляется каждый бар вверх, никогда вниз
    # Выход срабатывает когда цена падает ниже trail_stop
    trail_stop: float = 0.0

    # MACD Exit Warning — счётчик баров подряд с падающей гистограммой
    macd_warn_streak: int = 0
    macd_warned:      bool = False  # не спамим одним предупреждением
    # ФИКС: streak обновляется только один раз на каждый новый закрытый бар,
    # а не при каждом поллинге (60с) — иначе через 3 минуты ложные алерты на 30 монетах.
    last_macd_bar_i: int = -1

    def pnl_pct(self, current_price: float) -> float:
        return (current_price / self.entry_price - 1.0) * 100.0

    def prediction_summary(self) -> str:
        parts = []
        for h in config.FORWARD_BARS:
            result = self.predictions.get(h)
            if result is None:
                parts.append(f"T+{h}: ⏳")
            elif result:
                parts.append(f"T+{h}: ✅")
            else:
                parts.append(f"T+{h}: ❌")
        return "  ".join(parts)


# ── Shared monitor state ───────────────────────────────────────────────────────

@dataclass
class MonitorState:
    hot_coins:  List[CoinReport] = field(default_factory=list)
    positions:  Dict[str, OpenPosition] = field(default_factory=dict)
    running:    bool = False
    task:       Optional[asyncio.Task] = None
    # П3: cooldown после выхода — {symbol: unix_ms_until_which_skip}
    # Хранит unix-timestamp в мс до которого повторный вход заблокирован.
    # Всегда устанавливается как: data["t"][i] + COOLDOWN_BARS * bar_ms
    cooldowns:     Dict[str, int]  = field(default_factory=dict)
    # Флаг «cooldown уже залогирован» — отдельный dict чтобы не мешать типам
    cd_logged:     Dict[str, bool] = field(default_factory=dict)
    # Деdup для portfolio BLOCK логов: {symbol: последний_ts_ms когда логировали}.
    # Портфельный лимит проверяется каждые 60с → без dedup = 100+ строк на монету.
    # Логируем не чаще 1 раза в BLOCK_LOG_INTERVAL_BARS баров (по умолчанию 4 = 1ч на 15m).
    block_logged:  Dict[str, int]  = field(default_factory=dict)
    # Stage-1 warnings dedup: {"SYM|TF": last_ts_ms}
    early_warn_last: Dict[str, int] = field(default_factory=dict)
    # Last early warning message: {"SYM|TF": (ts_ms, text)}
    early_warn_msgs: Dict[str, Tuple[int, str]] = field(default_factory=dict)
    # Exit warnings dedup: {"SYM|TF": last_ts_ms}
    exit_warn_last: Dict[str, int] = field(default_factory=dict)


# ── Per-coin polling ───────────────────────────────────────────────────────────

async def _poll_coin(
    session: aiohttp.ClientSession,
    report:  CoinReport,
    state:   MonitorState,
    send:    SendFn,
) -> None:
    sym = report.symbol
    tf  = report.tf

    data = await fetch_klines(session, sym, tf, limit=config.LIVE_LIMIT)
    if data is None or len(data) < 60:
        return

    c    = data["c"].astype(float)
    feat = compute_features(data["o"], data["h"], data["l"], c, data["v"])
    i    = len(c) - 2  # last *closed* bar (index -1 is the forming bar)

    if i < 10:
        return

    pos = state.positions.get(sym)



    # ── No open position: look for entry ────────────────────────────────────
    if pos is None:
        # П3: cooldown — не входим повторно N баров после выхода
        # cooldown хранит unix-ms время до которого вход заблокирован
        cooldown_until_ms = state.cooldowns.get(sym, 0)
        current_ts_ms = int(data["t"][i])
        if current_ts_ms < cooldown_until_ms:
            bar_ms = 15 * 60 * 1000 if tf == "15m" else 60 * 60 * 1000
            bars_left = max(0, (cooldown_until_ms - current_ts_ms) // bar_ms)
            # Логируем только начало cooldown (когда bars_left максимальное)
            if not state.cd_logged.get(sym):
                botlog.log_cooldown(sym=sym, tf=tf, bars_remaining=int(bars_left), first=True)
                state.cd_logged[sym] = True
            return  # ещё в cooldown, пропускаем
        else:
            # Сбрасываем флаг «cooldown залогирован» когда cooldown истёк
            state.cd_logged.pop(sym, None)

        # ── Часовой фильтр (ML: 44K баров, 15.03.2026) ──────────────────
        # Блокируем входы в статистически убыточные часы UTC.
        # EV в часы [3,10-15] = -0.083%, в остальные = +0.200%.
        _block_hours = getattr(config, "ENTRY_BLOCK_HOURS", [])
        if _block_hours:
            _bar_hour_utc = int(data["t"][i] // 3_600_000) % 24
            if _bar_hour_utc in _block_hours:
                return  # тихий блок — не логируем (иначе спам каждую минуту)

        
        # ── Stage-1 EARLY warnings (NO ENTRY) ───────────────────────────────
        # Ранние детекторы начала тренда: EMA_CROSS / TREND_SURGE.
        # Важно: только предупреждение, без открытия позиции.
        try:
            _now_ms = int(data["t"][i])
            _key = f"{sym}|{tf}"
            _cool_ms = int(getattr(config, "EARLY_WARN_COOLDOWN_SEC", 3600) * 1000)
            _last_ms = state.early_warn_last.get(_key, 0)

            if _now_ms - _last_ms >= _cool_ms:
                ema_ok, ema_reason = check_ema_cross_conditions(feat, i)
                surge_ok, surge_reason = check_trend_surge_conditions(feat, i)

                if ema_ok or surge_ok:
                    _adx = float(feat["adx"][i]) if np.isfinite(feat["adx"][i]) else 0.0
                    _rsi = float(feat["rsi"][i]) if np.isfinite(feat["rsi"][i]) else 0.0
                    _vx  = float(feat["vol_x"][i]) if np.isfinite(feat["vol_x"][i]) else 0.0
                    _vj  = float(feat["vol_jump"][i]) if "vol_jump" in feat and np.isfinite(feat["vol_jump"][i]) else 0.0
                    _slp = float(feat["slope"][i]) if np.isfinite(feat["slope"][i]) else 0.0

                    if (_adx >= float(getattr(config, "EARLY_WARN_ADX_MIN", 12.0))
                        and _rsi <= float(getattr(config, "EARLY_WARN_RSI_MAX", 82.0))
                        and (_vx >= float(getattr(config, "EARLY_WARN_VOLX_MIN", 1.0))
                             or _vj >= float(getattr(config, "EARLY_WARN_VOLJUMP_MIN", 1.2)))):
                        _kind = "EMA_CROSS" if ema_ok else "TREND_SURGE"
                        _reason = ema_reason if ema_ok else surge_reason
                        _msg = (
                            f"⚠️ *EARLY WATCH — начало тренда*\n\n"
                            f"*{sym}*  `[{tf}]`  `{_kind}`\n"
                            f"Цена: `{c[i]:.6g}`  slope:`{_slp:+.2f}%`  ADX:`{_adx:.1f}`  RSI:`{_rsi:.1f}`  vol×:`{_vx:.2f}`\n"
                            f"_Причина: {_reason}_\n"
                            f"_Это предупреждение — вход не открывается_"
                        )
                        await send(
                            _msg
                        )
                        state.early_warn_msgs[_key] = (_now_ms, _msg)
                        state.early_warn_last[_key] = _now_ms
        except Exception:
            pass

        # П7: определяем тип сигнала — BREAKOUT > RETEST > strong_trend > trend > IMPULSE > ALIGNMENT
        entry_ok, _entry_reason = check_entry_conditions(feat, i, c)
        brk_ok,   _             = check_breakout_conditions(feat, i)
        ret_ok,   _             = check_retest_conditions(feat, i)
        imp_ok,   _             = check_impulse_conditions(feat, i)
        aln_ok,   _             = check_alignment_conditions(feat, i)

        any_signal = entry_ok or brk_ok or ret_ok or imp_ok or aln_ok
        if any_signal:
            # ── MTF-фильтр: для 1h сигналов проверяем 15м индикаторы ─────────
            # Защита от запоздавших 1h входов (пик на 15м уже давно прошёл).
            if tf == "1h" and getattr(config, "MTF_ENABLED", True):
                mtf_ok, mtf_reason = await _check_mtf(session, sym)
                if not mtf_ok:
                    log.info("MTF BLOCK %s [1h->15m]: %s", sym, mtf_reason)
                    botlog.log_blocked(sym, tf, 0.0, f"MTF: {mtf_reason}")
                    return

            # ── Портфельный лимит ─────────────────────────────────────────────
            port_ok, port_reason = _check_portfolio_limits(sym, state)
            if not port_ok:
                # Dedup: логируем не чаще 1 раза в BLOCK_LOG_INTERVAL_BARS баров.
                # Без dedup каждый 60с-тик пишет строку → 100-200 строк на монету в день.
                _block_interval = getattr(config, "BLOCK_LOG_INTERVAL_BARS", 4)
                bar_ms_b = 15 * 60 * 1000 if tf == "15m" else 60 * 60 * 1000
                _block_until = state.block_logged.get(sym, 0)
                _now_ms = int(data["t"][i]) if len(data["t"]) > i else 0
                if _now_ms >= _block_until:
                    log.info("PORTFOLIO BLOCK %s [%s]: %s", sym, tf, port_reason)
                    botlog.log_blocked(sym, tf, 0.0, f"портфель: {port_reason}")
                    state.block_logged[sym] = _now_ms + _block_interval * bar_ms_b
                return
            # П1: выбираем режим, trail_k и max_hold_bars
            if brk_ok:
                sig_mode  = "breakout"
                trail_k   = getattr(config, "ATR_TRAIL_K_BREAKOUT",  1.5)
                max_hold  = getattr(config, "MAX_HOLD_BARS_BREAKOUT", 6)
            elif ret_ok:
                sig_mode  = "retest"
                trail_k   = getattr(config, "ATR_TRAIL_K_RETEST",    1.8)
                max_hold  = getattr(config, "MAX_HOLD_BARS_RETEST",   10)
            elif entry_ok:
                mode     = get_entry_mode(feat, i)
                sig_mode = mode  # "trend" / "strong_trend" / "impulse_speed"
                # impulse_speed: ADX ещё не вырос, но цена уже летит → широкий стоп как у strong_trend
                if mode in ("strong_trend", "impulse_speed"):
                    trail_k = getattr(config, "ATR_TRAIL_K_STRONG", 2.5)
                else:
                    trail_k = config.ATR_TRAIL_K
                max_hold = (getattr(config, 'MAX_HOLD_BARS_15M', 48)
                            if tf == '15m' else config.MAX_HOLD_BARS)
            elif imp_ok:
                sig_mode = "impulse"
                trail_k  = getattr(config, "ATR_TRAIL_K", 2.0)
                max_hold = (getattr(config, "MAX_HOLD_BARS_15M", 48)
                            if tf == "15m" else getattr(config, "MAX_HOLD_BARS", 16))
            else:  # aln_ok
                sig_mode = "alignment"
                trail_k  = getattr(config, "ATR_TRAIL_K", 2.0)
                max_hold = (getattr(config, "MAX_HOLD_BARS_15M", 48)
                            if tf == "15m" else getattr(config, "MAX_HOLD_BARS", 16))

            price = float(c[i])
            ef    = float(feat["ema_fast"][i])
            slp   = float(feat["slope"][i])
            adx   = float(feat["adx"][i])
            rsi   = float(feat["rsi"][i])
            vx    = float(feat["vol_x"][i])

            atr_val    = float(feat["atr"][i]) if np.isfinite(feat["atr"][i]) else 0.0
            init_trail = price - trail_k * atr_val if atr_val > 0 else 0.0

            pos = OpenPosition(
                symbol=sym, tf=tf,
                entry_price=price,
                entry_bar=i,
                entry_ts=int(data["t"][i]),
                entry_ema20=ef,
                entry_slope=slp,
                entry_adx=adx,
                entry_rsi=rsi,
                entry_vol_x=vx,
                predictions={h: None for h in config.FORWARD_BARS},
                trail_stop=init_trail,
                signal_mode=sig_mode,
                trail_k=trail_k,
                max_hold_bars=max_hold,
            )
            # ── КРИТИЧНО: позиция сохраняется ПЕРВОЙ, до любых внешних вызовов.
            # Если ml_dataset или botlog выбросят исключение — позиция уже в state
            # и не потеряется. Именно это было причиной "нет позиций при сигналах".
            state.positions[sym] = pos
            save_positions(state.positions)  # персистируем при входе
            state.block_logged.pop(sym, None)  # сбросить dedup при входе
            log.info(
                "ENTRY %s [%s] %s price=%.6g rsi=%.1f adx=%.1f vol_x=%.2f",
                sym, tf, sig_mode, price, rsi, adx, vx,
            )

            # ML Dataset (некритично — ошибка не должна блокировать вход)
            _btc_vs_ema50 = getattr(config, "_btc_vs_ema50", 0.0)
            try:
                ml_id = ml_dataset.log_signal_candidate(
                    sym=sym, tf=tf,
                    bar_ts=int(data["t"][i]),
                    signal_type=sig_mode,
                    is_bull_day=getattr(config, "_bull_day_active", False),
                    feat=feat, i=i, data=data,
                    btc_vs_ema50=_btc_vs_ema50,
                )
                pos.ml_record_id = ml_id
            except Exception as _ml_err:
                log.warning("ml_dataset.log_signal_candidate failed for %s: %s", sym, _ml_err)

            # Операционный лог (некритично)
            try:
                _dr = float(feat["daily_range_pct"][i])
                _mh = float(feat["macd_hist"][i]) if np.isfinite(feat["macd_hist"][i]) else 0.0
                botlog.log_entry(
                    sym=sym, tf=tf, mode=sig_mode,
                    price=price, ema20=ef, slope=slp,
                    rsi=rsi, adx=adx, vol_x=vx,
                    macd_hist=_mh,
                    daily_range=_dr if np.isfinite(_dr) else 0.0,
                    trail_k=trail_k, max_hold_bars=max_hold,
                )
            except Exception as _log_err:
                log.warning("botlog.log_entry failed for %s: %s", sym, _log_err)

            # П7: метка типа сигнала
            _mode_labels = {
                "trend":        "📈 Тренд",
                "strong_trend": "💪 Сильный тренд",
                "impulse_speed":"⚡ Быстрое движение",
                "retest":       "🔄 Ретест EMA20",
                "breakout":     "⚡ Пробой флэта",
                "impulse":      "🚀 Импульс",
                "impulse_cross":"🚀 Импульс (кросс)",
                "alignment":    "🌊 Выравнивание тренда",
            }
            mode_label = _mode_labels.get(sig_mode, "📈 Тренд")

            await send(
                f"🟢 *СИГНАЛ ПОКУПКИ* — {mode_label}\n\n"
                f"*{sym}*  `[{tf}]`\n"
                f"💰 Цена: `{price:.6g}`\n"
                f"📐 EMA20: `{ef:.6g}`\n"
                f"📈 Наклон EMA20: `{slp:+.2f}%`\n"
                f"💪 ADX: `{adx:.1f}`\n"
                f"📊 RSI: `{rsi:.1f}`\n"
                f"🔊 Объём ×: `{vx:.2f}`\n"
                f"⚙️ Стоп: ATR×`{trail_k}`  |  Лимит: `{max_hold}` баров\n\n"
                f"🎯 Буду проверять прогноз: {pos.prediction_summary()}"
            )
        return

    # ── Open position: track predictions and check exit ──────────────────────

    # ИСПРАВЛЕНИЕ: entry_idx определяется ЗДЕСЬ, до любого использования.
    # Ищем бар входа по timestamp в текущем окне свечей.
    entry_idx: Optional[int] = None
    for k in range(len(data["t"])):
        if int(data["t"][k]) == pos.entry_ts:
            entry_idx = k
            break

    # bars_elapsed: реальное число баров с момента входа
    if entry_idx is not None:
        pos.bars_elapsed = i - entry_idx

    # ── ATR Trailing Stop: обновляем уровень каждый бар вверх ────────────────
    close_now = float(c[i])
    atr_now   = float(feat["atr"][i]) if np.isfinite(feat["atr"][i]) else 0.0
    if atr_now > 0:
        new_trail = close_now - pos.trail_k * atr_now  # П1: trail_k зависит от режима
        if new_trail > pos.trail_stop:
            pos.trail_stop = new_trail

    # Выход по ATR-трейлу
    if pos.trail_stop > 0 and close_now < pos.trail_stop:
        pnl      = pos.pnl_pct(close_now)
        pnl_icon = "🟢" if pnl >= 0 else "🔴"
        await send(
            f"🔴 *СИГНАЛ ПРОДАЖИ*\n\n"
            f"*{sym}*  `[{tf}]`\n"
            f"💰 Выход: `{close_now:.6g}`\n"
            f"📉 Причина: ATR-трейлинг пробит (стоп `{pos.trail_stop:.6g}`)\n"
            f"{pnl_icon} Изменение от входа: `{pnl:+.2f}%`\n"
            f"🎯 Точность прогнозов: {pos.prediction_summary()}\n"
            f"⏱ Баров в позиции: {pos.bars_elapsed}"
        )
        _exit_reason_atr = f"ATR-трейл пробит (стоп {pos.trail_stop:.6g})"
        botlog.log_exit(sym=sym, tf=tf, mode=getattr(pos,"signal_mode","trend"),
                        entry_price=pos.entry_price, exit_price=close_now,
                        reason=_exit_reason_atr,
                        bars_held=pos.bars_elapsed, trail_k=getattr(pos,"trail_k",2.0))
        if pos.ml_record_id:
            ml_dataset.fill_labels(pos.ml_record_id,
                exit_pnl=pos.pnl_pct(close_now),
                exit_reason=_exit_reason_atr,
                bars_held=pos.bars_elapsed)
        del state.positions[sym]
        save_positions(state.positions)  # персистируем при выходе
        bar_ms_cd = 15 * 60 * 1000 if tf == "15m" else 60 * 60 * 1000
        state.cooldowns[sym] = int(data["t"][i]) + getattr(config, "COOLDOWN_BARS", 8) * bar_ms_cd
        state.cd_logged.pop(sym, None)
        return

    # ── MACD Exit Warning: гистограмма падает N баров подряд ─────────────────
    # ФИКС Bug 8: streak обновляется только на НОВОМ закрытом баре (i != last_macd_bar_i).
    # Без этого при поллинге каждые 60с streak рос по тем же двум барам.
    macd_now  = feat["macd_hist"][i]
    macd_prev = feat["macd_hist"][i - 1] if i > 0 else np.nan
    if np.isfinite(macd_now) and np.isfinite(macd_prev) and i != pos.last_macd_bar_i:
        pos.last_macd_bar_i = i
        if macd_now < macd_prev:
            pos.macd_warn_streak += 1
        else:
            pos.macd_warn_streak = 0
            pos.macd_warned      = False  # сброс если MACD восстановился

    # Предупреждение только если: порог достигнут + ещё не предупреждали + прошло ≥ MACDWARN_BARS баров
    if (pos.macd_warn_streak >= config.MACDWARN_BARS
            and not pos.macd_warned
            and pos.bars_elapsed >= config.MACDWARN_BARS):
        pos.macd_warned = True
        # Dedup exit warnings
        _now_ms = int(data['t'][i])
        _ekey = f"{sym}|{tf}"
        _cd = int(getattr(config,'EXIT_WARN_COOLDOWN_SEC',2700)*1000)
        _last = state.exit_warn_last.get(_ekey, 0)
        if _now_ms - _last < _cd:
            return
        state.exit_warn_last[_ekey] = _now_ms
        cur_pnl = pos.pnl_pct(close_now)
        await send(
            f"⚠️ *Предупреждение о развороте*\n\n"
            f"*{sym}*  `[{tf}]`\n"
            f"MACD гистограмма падает {pos.macd_warn_streak} баров подряд\n"
            f"Текущий PnL: `{cur_pnl:+.2f}%`  Цена: `{close_now:.6g}`\n"
            f"_Сигнала продажи ещё нет — наблюдаем_"
        )

    # Check forward prediction horizons
    for h in config.FORWARD_BARS:
        if pos.predictions.get(h) is not None:
            continue  # already evaluated

        if entry_idx is None:
            continue  # entry bar no longer in window, skip

        target_bar = entry_idx + h
        # Target bar must exist AND be a closed bar (not the forming one)
        if target_bar > i:
            continue  # not yet reached

        future_price = float(c[target_bar])
        correct = future_price > pos.entry_price
        pos.predictions[h] = correct
        _ret_pct = (future_price / pos.entry_price - 1) * 100 if pos.entry_price > 0 else 0.0
        botlog.log_forward(sym=sym, tf=tf, mode=getattr(pos,"signal_mode","trend"),
                           horizon=h, entry_price=pos.entry_price,
                           forward_price=future_price, correct=correct)
        # ML: заполняем метку горизонта
        if pos.ml_record_id:
            ml_dataset.fill_forward_label(pos.ml_record_id, h, _ret_pct)
        pnl = pos.pnl_pct(future_price)
        icon = "✅" if correct else "⚠️"
        await send(
            f"{icon} *{sym}* — прогноз T+{h}\n"
            f"Вход: `{pos.entry_price:.6g}` → T+{h}: `{future_price:.6g}` "
            f"({pnl:+.2f}%)\n"
            f"{'✅ Предсказание верно' if correct else '❌ Предсказание НЕ подтвердилось'}\n"
            f"Статус: {pos.prediction_summary()}"
        )

    # П1: Принудительный выход — лимит баров зависит от режима сигнала
    if pos.bars_elapsed >= pos.max_hold_bars:
        price    = float(c[i])
        pnl      = pos.pnl_pct(price)
        pnl_icon = "🟢" if pnl >= 0 else "🔴"
        mins     = pos.max_hold_bars * (15 if tf == "15m" else 60)
        await send(
            f"⏱ *ВЫХОД ПО ВРЕМЕНИ*\n\n"
            f"*{sym}*  `[{tf}]`\n"
            f"💰 Выход: `{price:.6g}`\n"
            f"📉 Причина: лимит {pos.max_hold_bars} баров ({mins} мин) истёк\n"
            f"{pnl_icon} Изменение от входа: `{pnl:+.2f}%`\n"
            f"🎯 Точность прогнозов: {pos.prediction_summary()}\n"
            f"⏱ Баров в позиции: {pos.bars_elapsed}"
        )
        _exit_reason_time = f"время ({pos.max_hold_bars} баров)"
        botlog.log_exit(sym=sym, tf=tf, mode=getattr(pos,"signal_mode","trend"),
                        entry_price=pos.entry_price, exit_price=price,
                        reason=_exit_reason_time,
                        bars_held=pos.bars_elapsed, trail_k=getattr(pos,"trail_k",2.0))
        if pos.ml_record_id:
            ml_dataset.fill_labels(pos.ml_record_id,
                exit_pnl=pos.pnl_pct(price),
                exit_reason=_exit_reason_time,
                bars_held=pos.bars_elapsed)
        del state.positions[sym]
        save_positions(state.positions)  # персистируем при выходе
        # Cooldown: COOLDOWN_BARS * длина бара в мс
        bar_ms = 15 * 60 * 1000 if tf == "15m" else 60 * 60 * 1000
        state.cooldowns[sym] = int(data["t"][i]) + getattr(config, "COOLDOWN_BARS", 8) * bar_ms
        state.cd_logged.pop(sym, None)
        return

    # Check exit conditions
    # ФИКС: WEAK сигналы игнорируются первые MIN_WEAK_EXIT_BARS баров.
    # RSI дивергенция / vol exhaustion / EMA fan collapse могут существовать
    # ДО входа и немедленно выбивать позицию (AR 11.03.2026: выход на 0 баре).
    # Hard exits (ATR-трейл, время) защищены выше и не затронуты этим фильтром.
    min_weak_bars = getattr(config, "MIN_WEAK_EXIT_BARS", 2)
    reason = check_exit_conditions(feat, i, c)
    if reason:
        is_weak = reason.startswith("⚠️ WEAK:")
        if is_weak and pos.bars_elapsed < min_weak_bars:
            log.debug(
                "EXIT SUPPRESSED %s [%s] bars=%d < %d: %s",
                sym, tf, pos.bars_elapsed, min_weak_bars, reason
            )
            reason = None  # игнорируем WEAK на первых барах

    if reason:
        price = float(c[i])
        pnl   = pos.pnl_pct(price)
        pnl_icon = "🟢" if pnl >= 0 else "🔴"

        await send(
            f"🔴 *СИГНАЛ ПРОДАЖИ*\n\n"
            f"*{sym}*  `[{tf}]`\n"
            f"💰 Выход: `{price:.6g}`\n"
            f"📉 Причина: {reason}\n"
            f"{pnl_icon} Изменение от входа: `{pnl:+.2f}%`\n"
            f"🎯 Точность прогнозов: {pos.prediction_summary()}\n"
            f"⏱ Баров в позиции: {pos.bars_elapsed}"
        )
        botlog.log_exit(sym=sym, tf=tf, mode=getattr(pos,"signal_mode","trend"),
                        entry_price=pos.entry_price, exit_price=price,
                        reason=reason, bars_held=pos.bars_elapsed,
                        trail_k=getattr(pos,"trail_k",2.0))
        if pos.ml_record_id:
            ml_dataset.fill_labels(pos.ml_record_id,
                exit_pnl=pos.pnl_pct(price),
                exit_reason=reason,
                bars_held=pos.bars_elapsed)
        del state.positions[sym]
        save_positions(state.positions)  # персистируем при выходе
        bar_ms = 15 * 60 * 1000 if tf == "15m" else 60 * 60 * 1000
        state.cooldowns[sym] = int(data["t"][i]) + getattr(config, "COOLDOWN_BARS", 8) * bar_ms
        state.cd_logged.pop(sym, None)


# ── Main monitoring loop ───────────────────────────────────────────────────────

async def monitoring_loop(state: MonitorState, send: SendFn) -> None:
    symbols_str = ", ".join(r.symbol for r in state.hot_coins)
    try:
        await send(
            f"▶️ *Мониторинг запущен*\n"
            f"Слежу за *{len(state.hot_coins)}* монетами:\n"
            f"`{symbols_str}`\n"
            f"Интервал опроса: {config.POLL_SEC}с"
        )
    except Exception as e:
        log.warning("monitoring_loop: startup send failed: %s", e)

    _heartbeat_counter = 0
    async with aiohttp.ClientSession() as session:
        while state.running:
            try:
                tasks = [
                    _poll_coin(session, r, state, send)
                    for r in state.hot_coins
                ]
                results = await asyncio.gather(*tasks, return_exceptions=True)
                errors = [exc for exc in results if isinstance(exc, Exception)]
                if errors:
                    for exc in errors:
                        log.warning("Poll error: %s", exc)

                # Heartbeat каждые ~10 минут (600с / POLL_SEC итераций)
                _heartbeat_counter += 1
                if _heartbeat_counter % max(1, 600 // config.POLL_SEC) == 0:
                    log.info(
                        "monitoring_loop alive: %d coins, %d positions, errors=%d",
                        len(state.hot_coins), len(state.positions), len(errors),
                    )

            except Exception as e:
                log.error("Monitor loop error: %s", e)

            await asyncio.sleep(config.POLL_SEC)

    try:
        await send("⏹ *Мониторинг остановлен*")
    except Exception as e:
        log.warning("monitoring_loop: shutdown send failed: %s", e)
